ClumsyNX — сборка на GitHub с телефона
1. В репозиторий загрузи ClumsyNX_project.zip (не распаковывая) и файл .github/workflows/build.yml (текст — в чате).
2. Actions -> Build ClumsyNX -> скачай Artifact ClumsyNX-apk.
Вход: пароль разработчика (его нет в файлах) или подписанный код CNX2.… от разработчика.
