package com.clumsynx.app

import android.content.Context
import android.util.Base64
import java.io.DataInputStream
import java.security.KeyFactory
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.Signature
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * Пароля разработчика в приложении нет ни в каком виде — даже хэша.
 * Закрытый ключ подписи кодов лежит зашифрованным внутри файла assets/fonts.dat среди случайных данных;
 * расшифровать его можно только правильным паролем. Если ключ расшифровался — это разработчик.
 */
object Security {
    private val PUB = "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAE06jBUls0RTeDpq+joy5/VdSI4jmpKHdhvQXZbs6ThuJt/RSwj1RqbJ5to5Bkwyh2THqW0PZ8rRGve5uBubsBhQ=="
    private const val OFF = 4622777
    private const val LEN = 182
    private const val EPOCH = 1767225600000L // 2026-01-01 UTC
    private const val DAY = 86400000L
    private const val ITER = 100000

    @Volatile var devKey: PrivateKey? = null

    private fun pbkdf2(pw: ByteArray, salt: ByteArray): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(pw, "HmacSHA256"))
        mac.update(salt)
        mac.update(byteArrayOf(0, 0, 0, 1))
        var u = mac.doFinal()
        val t = u.copyOf()
        for (i in 1 until ITER) {
            u = mac.doFinal(u)
            for (j in t.indices) t[j] = (t[j].toInt() xor u[j].toInt()).toByte()
        }
        return t
    }

    fun unlockDev(ctx: Context, input: String): Boolean {
        val s = input.trim()
        if (s.isEmpty()) return false
        return try {
            val blob = ByteArray(LEN)
            DataInputStream(ctx.assets.open("fonts.dat")).use {
                var left = OFF
                while (left > 0) { val k = it.skipBytes(left); if (k <= 0) break; left -= k }
                it.readFully(blob)
            }
            val salt = blob.copyOfRange(0, 16)
            val nonce = blob.copyOfRange(16, 28)
            val ct = blob.copyOfRange(28, LEN)
            val key = pbkdf2(s.toByteArray(Charsets.UTF_8), salt)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, nonce))
            val der = c.doFinal(ct)
            devKey = KeyFactory.getInstance("EC").generatePrivate(PKCS8EncodedKeySpec(der))
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Создать подписанный код (только разработчик). days = 0 — бессрочно. */
    fun makeCode(days: Int): String? {
        val k = devKey ?: return null
        val day = if (days <= 0) 0xFFFF else ((System.currentTimeMillis() - EPOCH) / DAY + days).toInt().coerceIn(0, 0xFFFE)
        val p = ByteArray(8)
        p[0] = 2
        p[1] = (day shr 8).toByte(); p[2] = day.toByte()
        val serial = ByteArray(4); SecureRandom().nextBytes(serial)
        System.arraycopy(serial, 0, p, 3, 4)
        val sg = Signature.getInstance("SHA256withECDSA")
        sg.initSign(k); sg.update(p)
        val sig = sg.sign()
        return "CNX2." + Base64.encodeToString(p + sig, Base64.URL_SAFE or Base64.NO_WRAP or Base64.NO_PADDING)
    }

    /** Возвращает время окончания кода (мс) или null, если код поддельный. */
    fun verifyCode(code: String): Long? {
        return try {
            val t = code.trim()
            if (!t.startsWith("CNX2.")) return null
            val raw = Base64.decode(t.substring(5), Base64.URL_SAFE or Base64.NO_PADDING)
            if (raw.size < 10) return null
            val p = raw.copyOfRange(0, 8)
            val sig = raw.copyOfRange(8, raw.size)
            val pub = KeyFactory.getInstance("EC").generatePublic(X509EncodedKeySpec(Base64.decode(PUB, Base64.DEFAULT)))
            val v = Signature.getInstance("SHA256withECDSA")
            v.initVerify(pub); v.update(p)
            if (!v.verify(sig)) return null
            val day = ((p[1].toInt() and 255) shl 8) or (p[2].toInt() and 255)
            if (day == 0xFFFF) Long.MAX_VALUE else EPOCH + (day + 1) * DAY
        } catch (e: Exception) {
            null
        }
    }
}
