package com.clumsynx.app

import android.content.Context
import android.util.Base64
import androidx.compose.runtime.mutableStateOf
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

object Keys {
    /** Параметры без отдельного выбора направления */
    val params = setOf("burstWin", "dupN", "cli", "srv")

    val desc = mapOf(
        "cli" to "ПАКЕТЫ КЛИЕНТА. Шанс потерять пакеты, которые уходят ОТ тебя на сервер игры. 100% — от тебя ничего не доходит.",
        "srv" to "ПАКЕТЫ СЕРВЕРА. Шанс потерять пакеты, которые приходят К тебе от сервера. 100% — до тебя ничего не доходит.",
        "delay" to "ЗАДЕРЖКА (Lag). Каждый пакет ждёт перед отправкой. 100% = 1000 мс (1 секунда). Основной «лаг».",
        "jitter" to "ДЖИТТЕР. К задержке добавляется случайный разброс до 500 мс — пинг «скачет».",
        "loss" to "ПОТЕРИ (Drop). Шанс, что пакет пропадёт. 10% — рывки, 50% — играть почти нельзя. Для сайтов (TCP) вместо потери добавляется задержка повтора.",
        "spike" to "ЛАГ-СПАЙКИ. Редкие фризы на 0,5–3 секунды. Чем выше значение, тем чаще.",
        "burst" to "ПАЧКИ (Throttle). Шанс, что пакеты задержатся и придут одной пачкой — классический «лаг-свитч».",
        "burstWin" to "Окно пачки: сколько пакеты копятся перед выбросом. 100% = 1000 мс. Работает вместе с «Пачками».",
        "dup" to "ДУБЛИКАТЫ (Duplicate). Шанс, что пакет придёт несколько раз подряд (только UDP: игры, звонки).",
        "dupN" to "Сколько копий добавлять при дубликате: 0–20% = 1 копия, до 100% = 5 копий.",
        "reorder" to "НЕ ПО ПОРЯДКУ (Out of order). Пакеты приходят в перепутанном порядке (только UDP).",
        "corrupt" to "ПОРЧА ДАННЫХ (Tamper). Шанс, что в пакете испортится байт (только UDP).",
        "rst" to "СБРОС TCP (RST). Шанс, что соединение (сайт, приложение) внезапно оборвётся и переподключится.",
        "throttle" to "ОГРАНИЧЕНИЕ СКОРОСТИ (Bandwidth). 0% — без лимита, 100% — около 8 кбит/с."
    )
    val list = listOf(
        "cli" to "Пакеты клиента",
        "srv" to "Пакеты сервера",
        "delay" to "Задержка (Lag)",
        "jitter" to "Джиттер",
        "loss" to "Потеря пакетов (Drop)",
        "spike" to "Лаг-спайки (фризы)",
        "burst" to "Пачки (Throttle)",
        "burstWin" to "Окно пачки, мс",
        "dup" to "Дубликаты (Duplicate)",
        "dupN" to "Число копий",
        "reorder" to "Не по порядку (Out of order)",
        "corrupt" to "Порча данных (Tamper)",
        "rst" to "Сброс TCP (RST)",
        "throttle" to "Ограничение скорости"
    )
}

object Params {
    @Volatile var v: Map<String, Int> = emptyMap()
    @Volatile var dir: Int = 0
    @Volatile var effectEnd: Long = 0L
    @Volatile var ports: Set<Int> = emptySet()
    fun get(k: String): Int = v[k] ?: 0

    /** Значение с учётом выбранного направления (1 = входящие, 2 = исходящие, 3 = оба). */
    fun eff(k: String, outbound: Boolean): Int {
        val m = v["$k.d"] ?: 3
        val ok = if (outbound) (m and 2) != 0 else (m and 1) != 0
        return if (ok) get(k) else 0
    }
}

object Inbox { val pending = mutableStateOf<String?>(null) }

object VpnState {
    val running = mutableStateOf(false)
    val paused = mutableStateOf(false)
    @Volatile var pauseEnd: Long = 0L
}

data class Cfg(val name: String, val v: Map<String, Int>, val dir: Int, val dev: String = "", val desc: String = "") {
    fun toJson(): JSONObject = JSONObject().put("n", name).put("d", dir).put("dv", dev).put("ds", desc).put("v", JSONObject(v as Map<*, *>))

    fun share(): String =
        "CNX1:" + Base64.encodeToString(toJson().toString().toByteArray(), Base64.NO_WRAP or Base64.URL_SAFE)

    companion object {
        fun fromJson(o: JSONObject): Cfg {
            val vo = o.getJSONObject("v")
            val m = HashMap<String, Int>()
            vo.keys().forEach { m[it] = vo.getInt(it) }
            return Cfg(o.optString("n", "Конфиг"), m, o.optInt("d", 0), o.optString("dv", ""), o.optString("ds", ""))
        }

        fun parse(s: String): Cfg? = try {
            val t = s.trim()
            val b = if (t.startsWith("CNX1:")) t.substring(5) else t
            fromJson(JSONObject(String(Base64.decode(b, Base64.URL_SAFE))))
        } catch (e: Exception) {
            null
        }
    }
}

class Store(val ctx: Context) {
    private val p = ctx.getSharedPreferences("cnx", Context.MODE_PRIVATE)

    val deviceId: String
        get() {
            var id = p.getString("dev", null)
            if (id == null) {
                id = UUID.randomUUID().toString().take(12)
                p.edit().putString("dev", id).apply()
            }
            return id
        }

    var role: String
        get() = p.getString("role", "") ?: ""
        set(x) { p.edit().putString("role", x).apply() }

    var codeUsed: String
        get() = p.getString("code", "") ?: ""
        set(x) { p.edit().putString("code", x).apply() }

    var smart: Boolean
        get() = p.getBoolean("smart", false)
        set(x) { p.edit().putBoolean("smart", x).apply() }

    var active: String
        get() = p.getString("active", "") ?: ""
        set(x) { p.edit().putString("active", x).apply() }

    var fabOn: Boolean
        get() = p.getBoolean("fabOn", false)
        set(x) { p.edit().putBoolean("fabOn", x).apply() }

    var fabSize: Int
        get() = p.getInt("fabSize", 56)
        set(x) { p.edit().putInt("fabSize", x).apply() }

    var dir: Int
        get() = p.getInt("dir", 0)
        set(x) { p.edit().putInt("dir", x).apply() }

    var pauseSec: Int
        get() = p.getInt("pauseSec", 0)
        set(x) { p.edit().putInt("pauseSec", x).apply() }

    var effectSec: Int
        get() = p.getInt("effectSec", 0)
        set(x) { p.edit().putInt("effectSec", x).apply() }

    var ports: String
        get() = p.getString("ports", "") ?: ""
        set(x) { p.edit().putString("ports", x).apply() }

    var apps: Set<String>
        get() = (p.getString("apps", "") ?: "").split(",").filter { it.isNotBlank() }.toSet()
        set(x) { p.edit().putString("apps", x.joinToString(",")).apply() }

    fun loadValues(): Map<String, Int> {
        val o = JSONObject(p.getString("vals", "{}") ?: "{}")
        val m = HashMap<String, Int>()
        Keys.list.forEach { m[it.first] = o.optInt(it.first, 0) }
        o.keys().forEach { if (it.endsWith(".d") || it == "proto" || it == "auto") m[it] = o.optInt(it, 0) }
        return m
    }

    fun saveValues(m: Map<String, Int>, dir: Int) {
        p.edit().putString("vals", JSONObject(m as Map<*, *>).toString()).putInt("dir", dir).apply()
    }

    fun configs(): MutableList<Cfg> {
        val arr = JSONArray(p.getString("cfgs", "[]") ?: "[]")
        val out = mutableListOf<Cfg>()
        for (i in 0 until arr.length()) out.add(Cfg.fromJson(arr.getJSONObject(i)))
        return out
    }

    fun saveConfigs(l: List<Cfg>) {
        val arr = JSONArray()
        l.forEach { arr.put(it.toJson()) }
        p.edit().putString("cfgs", arr.toString()).apply()
    }

    fun rawGet(k: String): String = p.getString(k, "[]") ?: "[]"
    fun rawPut(k: String, v: String) { p.edit().putString(k, v).apply() }
}
