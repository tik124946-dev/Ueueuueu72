package com.clumsynx.app

class Preset(val name: String, val desc: String, val v: Map<String, Int>)

/** Стартовые шаблоны. Значения подобраны без доступа к играм — это отправная точка, а не проверенные конфиги. */
object Presets {
    val list = listOf(
        Preset("Standoff 2 — пол-интернета", "Половина пакетов теряется в обе стороны, небольшой джиттер.",
            mapOf("cli" to 50, "srv" to 50, "jitter" to 15)),
        Preset("Standoff 2 — стоппер", "Пакеты копятся и вылетают пачкой, короткие заморозки. Сам выключается через 10 с.",
            mapOf("burst" to 70, "burstWin" to 40, "delay" to 25, "spike" to 30, "auto" to 10)),
        Preset("Standoff 2 — инвиз", "Почти все исходящие пакеты теряются. Сам выключается через 5 с.",
            mapOf("cli" to 95, "srv" to 0, "delay" to 10, "auto" to 5)),
        Preset("Oxide — пол-интернета", "Половина пакетов теряется, лёгкая задержка.",
            mapOf("cli" to 50, "srv" to 50, "delay" to 10)),
        Preset("Oxide — лаг-свитч", "Пакеты не ходят в обе стороны. Сам выключается через 4 с.",
            mapOf("cli" to 100, "srv" to 100, "auto" to 4))
    )

    /** Подгон под качество интернета: чем хуже связь, тем слабее добавочные задержки. */
    fun scale(v: Map<String, Int>, q: Int): Map<String, Int> {
        val f = 0.5 + q / 200.0
        val keys = setOf("delay", "jitter", "spike", "burst", "cli", "srv")
        return v.mapValues { (k, x) -> if (k in keys) (x * f).toInt().coerceIn(0, 100) else x }
    }
}
