package com.clumsynx.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.VpnService
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Random
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Движок: VPN-туннель, через который все пакеты проходят через ClumsyNX.
 * ПАУЗА = все пакеты выбрасываются (интернет полностью стоит).
 * Остальные ползунки искажают трафик (UDP — полностью, TCP — задержка/ограничение скорости).
 */
class ClumsyVpnService : VpnService() {
    private var tun: ParcelFileDescriptor? = null
    private var out: FileOutputStream? = null
    private val outLock = Any()
    @Volatile private var alive = false
    private val pool = Executors.newCachedThreadPool()
    private val sched = Executors.newScheduledThreadPool(4)
    private val udp = ConcurrentHashMap<String, UdpFlow>()
    private val tcp = ConcurrentHashMap<String, TcpFlow>()
    private val rnd = Random()
    private var nextFreeIn = 0L
    private var nextFreeOut = 0L
    private var screenRx: BroadcastReceiver? = null
    private val main = Handler(Looper.getMainLooper())
    private val resumeRun = Runnable { doResume() }

    private val M = 0xFFFFFFFFL
    private val FIN = ByteArray(0)

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        when (i?.action) {
            "STOP" -> { stopAll(); stopSelf() }
            "PAUSE" -> doPause()
            "RESUME" -> doResume()
            else -> start()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        stopAll()
        super.onDestroy()
    }

    override fun onRevoke() {
        stopAll()
        super.onRevoke()
    }

    private fun doPause() {
        VpnState.paused.value = true
        main.removeCallbacks(resumeRun)
        val s = Store(applicationContext).pauseSec
        if (s > 0) {
            VpnState.pauseEnd = System.currentTimeMillis() + s * 1000L
            main.postDelayed(resumeRun, s * 1000L)
        } else {
            VpnState.pauseEnd = 0L
        }
    }

    private fun doResume() {
        main.removeCallbacks(resumeRun)
        VpnState.pauseEnd = 0L
        VpnState.paused.value = false
        setEffectTimer()
    }

    private fun setEffectTimer() {
        val s = Store(applicationContext).effectSec
        Params.effectEnd = if (s > 0) System.currentTimeMillis() + s * 1000L else 0L
    }

    private fun start() {
        if (alive) return
        val b = Builder()
            .setSession("ClumsyNX")
            .setMtu(1400)
            .addAddress("10.8.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .addDnsServer("8.8.8.8")
        try { b.addAddress("fd00:1::2", 128); b.addRoute("::", 0) } catch (e: Exception) { }
        val chosen = Store(applicationContext).apps
        var any = false
        for (pkg in chosen) { try { b.addAllowedApplication(pkg); any = true } catch (e: Exception) { } }
        if (!any) { try { b.addDisallowedApplication(packageName) } catch (e: Exception) { } }
        Params.ports = Store(applicationContext).ports.split(",", " ", ";").mapNotNull { it.trim().toIntOrNull() }.toSet()
        setEffectTimer()
        val fd = b.establish() ?: return
        tun = fd
        out = FileOutputStream(fd.fileDescriptor)
        alive = true
        VpnState.running.value = true
        VpnState.paused.value = false
        VpnState.pauseEnd = 0L

        screenRx = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) {
                if (intent?.action == Intent.ACTION_SCREEN_OFF && Store(applicationContext).smart) {
                    stopAll(); stopSelf()
                }
            }
        }
        registerReceiver(screenRx, IntentFilter(Intent.ACTION_SCREEN_OFF))

        val input = FileInputStream(fd.fileDescriptor)
        pool.execute {
            val buf = ByteArray(32767)
            while (alive) {
                val n = try { input.read(buf) } catch (e: Exception) { -1 }
                if (n < 0) break
                if (n > 0) try { process(buf, n) } catch (e: Exception) { }
            }
        }
    }

    private fun stopAll() {
        if (!alive && tun == null) { VpnState.running.value = false; return }
        alive = false
        main.removeCallbacks(resumeRun)
        Params.effectEnd = 0L
        VpnState.pauseEnd = 0L
        VpnState.running.value = false
        VpnState.paused.value = false
        try { screenRx?.let { unregisterReceiver(it) } } catch (e: Exception) { }
        screenRx = null
        udp.values.forEach { it.close() }; udp.clear()
        tcp.values.forEach { closeTcp(it) }; tcp.clear()
        try { tun?.close() } catch (e: Exception) { }
        tun = null
        out = null
    }

    // ---------- утилиты пакетов ----------
    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 255) shl 8) or (b[o + 1].toInt() and 255)
    private fun u32(b: ByteArray, o: Int): Long =
        ((b[o].toLong() and 255) shl 24) or ((b[o + 1].toLong() and 255) shl 16) or
            ((b[o + 2].toLong() and 255) shl 8) or (b[o + 3].toLong() and 255)

    private fun p16(b: ByteArray, o: Int, v: Int) { b[o] = (v shr 8).toByte(); b[o + 1] = v.toByte() }
    private fun p32(b: ByteArray, o: Int, v: Long) {
        b[o] = (v shr 24).toByte(); b[o + 1] = (v shr 16).toByte(); b[o + 2] = (v shr 8).toByte(); b[o + 3] = v.toByte()
    }

    private fun ipStr(b: ByteArray) = "${b[0].toInt() and 255}.${b[1].toInt() and 255}.${b[2].toInt() and 255}.${b[3].toInt() and 255}"

    private fun checksum(b: ByteArray, off: Int, len: Int): Int {
        var s = 0L
        var i = off
        val end = off + len
        while (i + 1 < end) { s += ((b[i].toInt() and 255) shl 8) or (b[i + 1].toInt() and 255); i += 2 }
        if (i < end) s += (b[i].toInt() and 255) shl 8
        while ((s shr 16) != 0L) s = (s and 0xffff) + (s shr 16)
        return (s.inv() and 0xffff).toInt()
    }

    private fun ipPacket(proto: Int, src: ByteArray, dst: ByteArray, l4: ByteArray): ByteArray {
        val p = ByteArray(20 + l4.size)
        p[0] = 0x45
        p16(p, 2, p.size)
        p[6] = 0x40
        p[8] = 64
        p[9] = proto.toByte()
        System.arraycopy(src, 0, p, 12, 4)
        System.arraycopy(dst, 0, p, 16, 4)
        p16(p, 10, checksum(p, 0, 20))
        System.arraycopy(l4, 0, p, 20, l4.size)
        return p
    }

    private fun writeTun(p: ByteArray) {
        synchronized(outLock) { try { out?.write(p) } catch (e: Exception) { } }
    }

    // ---------- искажение трафика ----------
    private class Plan(val delay: Long, val copies: Int, val corrupt: Boolean)

    /** null = пакет выбросить. */
    private fun plan(isUdp: Boolean, outbound: Boolean, size: Int, exempt: Boolean): Plan? {
        if (exempt || !effectsOn()) return Plan(0, 1, false)
        fun e(k: String) = Params.eff(k, outbound)
        val loss = maxOf(e("loss"), if (outbound) Params.get("cli") else Params.get("srv"))
        if (isUdp && loss > 0 && rnd.nextInt(100) < loss) return null
        var delay = e("delay") * 10L
        // для TCP потеря = задержка на повторную отправку, как в реальной сети
        if (!isUdp && loss > 0 && rnd.nextInt(100) < loss) delay += 200L + rnd.nextInt(400)
        val jit = e("jitter")
        if (jit > 0) delay += rnd.nextInt(jit * 5 + 1)
        val spike = e("spike")
        if (spike > 0 && rnd.nextInt(1000) < spike * 3) delay += 500L + rnd.nextInt(2500)
        val burst = e("burst")
        if (burst > 0 && rnd.nextInt(100) < burst) {
            val win = maxOf(10L, Params.get("burstWin") * 10L)
            delay += win - (System.currentTimeMillis() % win)
        }
        if (isUdp) {
            val re = e("reorder")
            if (re > 0 && rnd.nextInt(100) < re) delay += rnd.nextInt(120)
        }
        val th = e("throttle")
        if (th > 0) {
            val kbps = (2000.0 * (100 - th) / 100.0).coerceAtLeast(8.0)
            val serial = (size * 8.0 / kbps).toLong()
            synchronized(this) {
                val now = System.currentTimeMillis()
                if (outbound) {
                    nextFreeOut = maxOf(now, nextFreeOut) + serial
                    delay += minOf(nextFreeOut - now, 5000L)
                } else {
                    nextFreeIn = maxOf(now, nextFreeIn) + serial
                    delay += minOf(nextFreeIn - now, 5000L)
                }
            }
        }
        val dup = e("dup")
        val copies = if (isUdp && dup > 0 && rnd.nextInt(100) < dup) 1 + maxOf(1, Params.get("dupN") / 20) else 1
        val cor = e("corrupt")
        val corrupt = isUdp && cor > 0 && rnd.nextInt(100) < cor
        return Plan(delay, copies, corrupt)
    }

    private fun effectsOn(): Boolean {
        val end = Params.effectEnd
        return end == 0L || System.currentTimeMillis() <= end
    }

    /** Фильтр протокола и портов (как фильтр в Clumsy). false = этот трафик не трогаем. */
    private fun matches(isUdp: Boolean, remotePort: Int): Boolean {
        val pr = Params.get("proto")
        if (pr == 1 && !isUdp) return false
        if (pr == 2 && isUdp) return false
        val ps = Params.ports
        return ps.isEmpty() || ps.contains(remotePort)
    }

    private fun rstHit(outbound: Boolean): Boolean {
        val r = Params.eff("rst", outbound)
        return r > 0 && effectsOn() && rnd.nextInt(1000) < r * 2
    }

    private fun corruptBytes(b: ByteArray): ByteArray {
        if (b.isEmpty()) return b
        val c = b.copyOf()
        c[rnd.nextInt(c.size)] = rnd.nextInt(256).toByte()
        return c
    }

    // ---------- разбор пакетов ----------
    private fun process(b: ByteArray, len: Int) {
        if (((b[0].toInt() shr 4) and 15) != 4) return // IPv6 и прочее — не пропускаем
        if (VpnState.paused.value) return // ПАУЗА: всё выбрасываем
        val ihl = (b[0].toInt() and 15) * 4
        val total = u16(b, 2)
        if (total > len || total < ihl + 8) return
        when (b[9].toInt() and 255) {
            17 -> handleUdp(b, ihl, total)
            6 -> handleTcp(b, ihl, total)
        }
    }

    // ---------- UDP ----------
    private inner class UdpFlow(val key: String, val cip: ByteArray, val cport: Int, val sip: ByteArray, val sport: Int) {
        val sock = DatagramSocket()
        val addr = InetSocketAddress(InetAddress.getByAddress(sip), sport)

        init {
            protect(sock)
            sock.soTimeout = 60000
            pool.execute {
                val buf = ByteArray(65535)
                try {
                    while (alive) {
                        val pk = DatagramPacket(buf, buf.size)
                        sock.receive(pk)
                        val data = buf.copyOf(pk.length)
                        val pl = plan(true, false, data.size, sport == 53 || !matches(true, sport)) ?: continue
                        repeat(pl.copies) {
                            sched.schedule(Runnable {
                                val payload = if (pl.corrupt) corruptBytes(data) else data
                                val l4 = ByteArray(8 + payload.size)
                                p16(l4, 0, sport); p16(l4, 2, cport); p16(l4, 4, l4.size)
                                System.arraycopy(payload, 0, l4, 8, payload.size)
                                writeTun(ipPacket(17, sip, cip, l4))
                            }, pl.delay, TimeUnit.MILLISECONDS)
                        }
                    }
                } catch (e: Exception) { }
                close()
            }
        }

        fun send(data: ByteArray) {
            try { sock.send(DatagramPacket(data, data.size, addr)) } catch (e: Exception) { }
        }

        fun close() {
            try { sock.close() } catch (e: Exception) { }
            udp.remove(key)
        }
    }

    private fun handleUdp(b: ByteArray, ihl: Int, total: Int) {
        val sp = u16(b, ihl)
        val dp = u16(b, ihl + 2)
        val plen = u16(b, ihl + 4) - 8
        if (plen < 0 || ihl + 8 + plen > total) return
        val payload = b.copyOfRange(ihl + 8, ihl + 8 + plen)
        val src = b.copyOfRange(12, 16)
        val dst = b.copyOfRange(16, 20)
        val key = "$sp>${ipStr(dst)}:$dp"
        val flow = udp[key] ?: UdpFlow(key, src, sp, dst, dp).also { udp[key] = it }
        val pl = plan(true, true, plen, dp == 53 || !matches(true, dp)) ?: return
        repeat(pl.copies) {
            sched.schedule(Runnable { flow.send(if (pl.corrupt) corruptBytes(payload) else payload) }, pl.delay, TimeUnit.MILLISECONDS)
        }
    }

    // ---------- TCP (упрощённый релей) ----------
    private inner class TcpFlow(val key: String, val cip: ByteArray, val cport: Int, val sip: ByteArray, val sport: Int) {
        @Volatile var rcvNxt = 0L
        @Volatile var sndNxt = 0L
        @Volatile var cliAck = 0L
        @Volatile var cliWnd = 65535
        @Volatile var established = false
        @Volatile var closed = false
        @Volatile var cliFin = false
        @Volatile var srvFin = false
        var sock: Socket? = null
        val q = LinkedBlockingQueue<ByteArray>()
    }

    private fun sendTcp(f: TcpFlow, flags: Int, payload: ByteArray) {
        synchronized(f) {
            val l4 = ByteArray(20 + payload.size)
            p16(l4, 0, f.sport); p16(l4, 2, f.cport)
            p32(l4, 4, f.sndNxt and M); p32(l4, 8, f.rcvNxt and M)
            l4[12] = 0x50
            l4[13] = flags.toByte()
            p16(l4, 14, 65535)
            System.arraycopy(payload, 0, l4, 20, payload.size)
            val ps = ByteArray(12 + l4.size)
            System.arraycopy(f.sip, 0, ps, 0, 4); System.arraycopy(f.cip, 0, ps, 4, 4)
            ps[9] = 6; p16(ps, 10, l4.size)
            System.arraycopy(l4, 0, ps, 12, l4.size)
            p16(l4, 16, checksum(ps, 0, ps.size))
            writeTun(ipPacket(6, f.sip, f.cip, l4))
            var adv = payload.size.toLong()
            if (flags and 0x03 != 0) adv += 1 // SYN или FIN занимают 1 номер
            f.sndNxt = (f.sndNxt + adv) and M
        }
    }

    private fun closeTcp(f: TcpFlow) {
        f.closed = true
        try { f.sock?.close() } catch (e: Exception) { }
        f.q.offer(FIN)
        tcp.remove(f.key)
    }

    private fun handleTcp(b: ByteArray, ihl: Int, total: Int) {
        if (total < ihl + 20) return
        val sp = u16(b, ihl)
        val dp = u16(b, ihl + 2)
        val seq = u32(b, ihl + 4)
        val ack = u32(b, ihl + 8)
        val doff = ((b[ihl + 12].toInt() and 0xf0) shr 4) * 4
        val flags = b[ihl + 13].toInt() and 0x3f
        val wnd = u16(b, ihl + 14)
        val dataOff = ihl + doff
        val dlen = total - dataOff
        if (dlen < 0) return
        val src = b.copyOfRange(12, 16)
        val dst = b.copyOfRange(16, 20)
        val key = "$sp>${ipStr(dst)}:$dp"
        var f = tcp[key]
        val syn = flags and 2 != 0
        val ackf = flags and 16 != 0
        val fin = flags and 1 != 0
        val rst = flags and 4 != 0

        if (rst) { f?.let { closeTcp(it) }; return }
        if (syn && !ackf) {
            if (f != null) return
            val nf = TcpFlow(key, src, sp, dst, dp)
            nf.rcvNxt = (seq + 1) and M
            nf.sndNxt = rnd.nextInt().toLong() and M
            tcp[key] = nf
            pool.execute { connectTcp(nf) }
            return
        }
        if (f == null || !f.established) return
        if (ackf) { f.cliAck = ack; f.cliWnd = wnd }
        if (dlen > 0 && matches(false, f.sport) && rstHit(true)) {
            sendTcp(f, 0x04, ByteArray(0))
            closeTcp(f)
            return
        }
        if (dlen > 0) {
            if (seq == f.rcvNxt) {
                f.rcvNxt = (f.rcvNxt + dlen) and M
                f.q.offer(b.copyOfRange(dataOff, dataOff + dlen))
            }
            sendTcp(f, 0x10, ByteArray(0))
        }
        if (fin && ((seq + dlen) and M) == f.rcvNxt && !f.cliFin) {
            f.cliFin = true
            f.rcvNxt = (f.rcvNxt + 1) and M
            f.q.offer(FIN)
            sendTcp(f, 0x10, ByteArray(0))
            if (f.srvFin) closeTcp(f)
        }
    }

    private fun connectTcp(f: TcpFlow) {
        try {
            val s = Socket()
            protect(s)
            s.connect(InetSocketAddress(InetAddress.getByAddress(f.sip), f.sport), 8000)
            s.tcpNoDelay = true
            f.sock = s
            f.cliAck = (f.sndNxt + 1) and M
            f.established = true
            sendTcp(f, 0x12, ByteArray(0)) // SYN+ACK

            // запись данных от приложения в сеть (с задержкой)
            pool.execute {
                try {
                    val os = s.getOutputStream()
                    while (!f.closed) {
                        val d = f.q.take()
                        if (d === FIN) { try { s.shutdownOutput() } catch (e: Exception) { }; break }
                        val pl = plan(false, true, d.size, !matches(false, f.sport))
                        if (pl != null && pl.delay > 0) Thread.sleep(pl.delay)
                        os.write(d)
                    }
                } catch (e: Exception) { closeTcp(f) }
            }
            // чтение из сети и отправка приложению
            pool.execute {
                val buf = ByteArray(1300)
                try {
                    val ins = s.getInputStream()
                    while (!f.closed) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        while (!f.closed) {
                            val inflight = ((f.sndNxt - f.cliAck) and M).toInt()
                            if (inflight <= 0 || inflight + n <= maxOf(f.cliWnd, 1)) break
                            Thread.sleep(2)
                        }
                        if (matches(false, f.sport) && rstHit(false)) {
                            sendTcp(f, 0x04, ByteArray(0))
                            closeTcp(f)
                            break
                        }
                        val pl = plan(false, false, n, !matches(false, f.sport))
                        if (pl != null && pl.delay > 0) Thread.sleep(pl.delay)
                        sendTcp(f, 0x18, buf.copyOf(n))
                    }
                } catch (e: Exception) { }
                if (!f.closed) {
                    sendTcp(f, 0x11, ByteArray(0))
                    f.srvFin = true
                    if (f.cliFin) closeTcp(f)
                }
            }
        } catch (e: Exception) {
            f.established = true
            sendTcp(f, 0x14, ByteArray(0)) // RST
            closeTcp(f)
        }
    }
}
